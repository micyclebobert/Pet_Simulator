package com.cse215.g2.pet_simulator;

public abstract class Menu {
    abstract void setup();
    abstract void open();
abstract void close();
}
