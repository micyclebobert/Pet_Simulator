package com.cse215.g2.pet_simulator;

public class Cat extends Animal {
    public Cat(String name) {
        super(name);
    }
}