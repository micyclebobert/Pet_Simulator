Project Update: https://docs.google.com/document/d/15Z4CPyu0099eKtB9DxynfDyHVB-bHzXc/edit?usp=sharing&ouid=101946606246263599149&rtpof=true&sd=true
